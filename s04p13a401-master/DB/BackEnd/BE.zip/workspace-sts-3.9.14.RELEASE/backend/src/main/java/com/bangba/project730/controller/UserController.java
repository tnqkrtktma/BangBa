package com.bangba.project730.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bangba.project730.model.dto.User;
import com.bangba.project730.model.service.UserService;

import io.swagger.annotations.ApiOperation;

@Controller
@RequestMapping("/user")
public class UserController {
	
	private UserService userService;
	
	@ApiOperation(value = "회원가입 실행", response = String.class)
	@PostMapping("/create")
	public String createUser(User user, Model model) throws Exception {
		try {
			userService.createUser(user);
			model.addAttribute("msg", "회원가입 완료");
			return "signup";
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "회원가입중 문제가 발생했습니다.");
			return "signup";
		}
	}
	
}
