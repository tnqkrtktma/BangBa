package com.bangba.project730.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bangba.project730.model.dto.User;
import com.bangba.project730.model.service.UserService;

import io.swagger.annotations.ApiOperation;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@ApiOperation(value = "회원가입 실행", response = String.class)
	@PostMapping("/create")
	public String createUser(User user, Model model) throws Exception {
		try {
			userService.createUser(user);
			model.addAttribute("msg", "회원가입 완료");
			return "signup";
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "회원가입중 문제가 발생했습니다.");
			return "signup";
		}
	}
	
	@ApiOperation(value = "로그인", response = String.class)
	@PostMapping(value="/login")
	public String login(@RequestParam Map<String, String> map, Model model, HttpSession session) {
		try {
			User user = userService.login(map);
			if(user != null) {
				session.setAttribute("userinfo", user);
			} else {
				model.addAttribute("msg", "아이디 또는 비밀번호를 확인 후 로그인해 주세요.");
			}
			return "main";
		}catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "로그인 중 문제가 발생했습니다.");
			return "error/error";
		}
	}
	
	@GetMapping(value="/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "test";
	}
	
}
