package com.bangba.project730.model.service;

import java.util.Map;

import com.bangba.project730.model.dto.User;

public interface UserService {
	public void createUser(User user) throws Exception;
	public User login(Map<String, String> map) throws Exception;
}
