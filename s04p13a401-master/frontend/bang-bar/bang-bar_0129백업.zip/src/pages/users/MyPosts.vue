<template>
    <div class="h-screen text-center bg-white mx-24 my-12">
    <span class="text-4xl font-bold">내가 쓴 글</span>
    </div>
</template>

<style scoped>
div {
    border-radius: 45px;
}
</style>