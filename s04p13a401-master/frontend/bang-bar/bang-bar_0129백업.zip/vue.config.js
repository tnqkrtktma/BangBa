module.exports = {
    configureWebpack: {
      module: {
        rules: [
          {
            test: /\.css$/,
            use: ['postcss-loader']
          }
        ]
      }
    }
  }