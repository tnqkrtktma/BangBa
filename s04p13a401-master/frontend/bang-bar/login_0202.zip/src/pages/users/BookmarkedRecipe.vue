<template>
    <div class="h-screen text-center bg-white mx-24 my-12">
    <span class="text-4xl font-bold">북마크한 레시피</span>
    </div>
</template>

<style scoped>
div {
    border-radius: 45px;
}
</style>